# Aurelia PMS Android APK source

This project packages the supplied `aurelia_pms_improved.html` as a local HTML asset inside a Flutter Android WebView.

## Build APK with GitHub Actions (Android phone friendly)

1. Create a GitHub repository and upload the **contents** of this folder.
2. Commit the files to the `main` branch.
3. Open the repository on GitHub, go to **Actions**, select **Build Aurelia PMS APK**, then choose **Run workflow** (or push a commit).
4. When the workflow finishes, open its run page and download the `aurelia-pms-release-apk` artifact.
5. Extract the artifact ZIP to get `app-release.apk`, then install it on your Android phone. Android may ask you to allow installs from that source.

## Local build

Install Flutter SDK and Android SDK, then run:

```bash
flutter create . --platforms=android --project-name aurelia_pms
flutter pub get
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`

## Important functionality notes

- The HTML is included unchanged from the supplied `aurelia_pms_improved.html`.
- WebView JavaScript and DOM storage are enabled so the app can use browser storage in the app's WebView context.
- The app needs internet access for HTML features that load external scripts/services (for example OCR/PDF libraries, Google sign-in/Drive integrations, or remote QR services).
- Data saved in the WebView is local to this app installation. It is not automatically synced across devices. Export backups regularly.
- Google Drive backup requires OAuth configuration.
- WebAuthn/biometric enrollment may not work in an embedded WebView without native Android integration and server-side challenge validation.
- HTML file uploads, camera access, printing, downloads, external sign-in redirects, and native Android notifications may need additional Android-specific integrations. This wrapper is a buildable starting point, not proof that every feature has been runtime-tested.
- Do not use real guest identity documents or payment data until security, backup, access control, and export workflows have been tested.

## Included files

- `assets/index.html` — supplied PMS HTML
- `lib/main.dart` — Flutter WebView app
- `pubspec.yaml` — Flutter dependencies
- `.github/workflows/build-apk.yml` — automated APK build
